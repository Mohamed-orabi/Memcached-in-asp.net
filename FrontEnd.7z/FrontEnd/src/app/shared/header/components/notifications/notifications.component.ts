import { Component } from '@angular/core';
import * as signalR from '@microsoft/signalr';
// import { NotificationCountResult, NotificationResult } from 'src/app/module/request/models';
import { AppConfigService } from 'src/app/shared/AppConfigService';
import { ModalService } from '../../containers/modal/modal.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})

export class NotificationsComponent {
 
   api = AppConfigService.appConfig.HubURL
count:number=0;
  // notification: NotificationCountResult;
  // messages: Array<NotificationResult>;
  errorMessage = '';

  constructor( private modalService: ModalService) { }
  isExpanded = false;

  ngOnInit() {
    this.getNotificationCount();
    const connection = new signalR.HubConnectionBuilder()
      .configureLogging(signalR.LogLevel.Information)
      .withUrl(this.api + 'notify')
      .build();

    connection.start().then(function () {
      console.log('SignalR Connected!');
    }).catch(function (err) {
      return console.error(err.toString());
    });

    connection.on("BroadcastMessage", () => {
      debugger
      this.count++;
      this.getNotificationCount();
    });
  }

  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }

  getNotificationCount() {
    // this.notification?.count==undefined?1:+1
     // this.notificationService.getNotificationCount().subscribe(
    //   notification => {
    //     this.notification = notification;
    //   },
    //   error => this.errorMessage = <any>error
    // );
  }

  getNotificationMessage() {
    // this.notificationService.getNotificationMessage().subscribe(
    //   messages => {
    //     this.messages = messages;
    //   },
    //   error => this.errorMessage = <any>error
    // );
  }

  deleteNotifications(): void {
    // if (confirm(`Are you sure want to delete all notifications?`)) {
    //   this.notificationService.deleteNotifications()
    //     .subscribe(
    //       () => {
    //         this.closeModal();
    //       },
    //       (error: any) => this.errorMessage = <any>error
    //     );
    // }
  }
  openModal() {
    this.getNotificationMessage();
    this.modalService.open('custom-modal');
  }

  closeModal() {
    this.modalService.close('custom-modal');
  }
}
