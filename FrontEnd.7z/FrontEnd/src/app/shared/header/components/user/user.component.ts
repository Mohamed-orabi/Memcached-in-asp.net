import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
// import { UserServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';

import { routes } from '../../../../consts'; 

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit{ 
  @Output() signOut: EventEmitter<void> = new EventEmitter<void>();
  public routes: typeof routes = routes;
  public flatlogicEmail: string = "https://flatlogic.com";
name="";
group="";
  /**
   *
   */
  constructor(
    // private userServiceProxy:UserServiceProxy
    )  {
    ;

  }

  ngOnInit() {
    // let token = window.location.hash.replace('#', '');
    // if (token) {
    //   window.localStorage.setItem('token', token);
    //   window.location.hash = '';
    // } else if (
    //   localStorage.getItem('token') == undefined ||
    //   localStorage.getItem('token') == null
    // ) {
    //   window.location.href = `${routes.SSOLOGIN}`;
    // } 
    // this.userServiceProxy.getUserInfo().subscribe((res) => {
    //   if (res) {  
    //     this.name=res.name;
    //     this.group=res.groupName;
    //     localStorage.setItem('PAS',JSON.stringify(res.pageActionId))
    //     localStorage.setItem('Name',this.name)
    //     localStorage.setItem('Group',this.group)

    //   }
    // }); 
  }

  public signOutEmit(): void {
    this.signOut.emit();
  }
}
