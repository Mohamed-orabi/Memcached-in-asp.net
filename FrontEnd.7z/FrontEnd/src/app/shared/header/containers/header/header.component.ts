import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

import { routes } from '../../../../consts';
import { AppConfigService } from 'src/app/shared/AppConfigService';
import { HttpClient } from '@angular/common/http';
import { UserComponent } from '../../components';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() isMenuOpened: boolean;
  @Output() isShowSidebar = new EventEmitter<boolean>();

  public routers: typeof routes = routes;
  test: string;
  role = localStorage.getItem('Group');

  constructor(
    private router: Router,
    public http: HttpClient,
    private appConfigService: AppConfigService,

  ) {

  }
  ngOnInit() {
    //  this.user$.firstname=localStorage.getItem("fname").toString();
    //  this.user$.lastName=localStorage.getItem("lname").toString(); 
  }
  public openMenu(): void {
    this.isMenuOpened = !this.isMenuOpened;

    this.isShowSidebar.emit(this.isMenuOpened);
  }

  public signOut(): void {
    localStorage.clear();
    window.location.reload();

  }
}
