import { HttpClient, HttpEvent, HttpEventType, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable, InjectionToken, Optional } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { routes } from 'src/app/consts';
// import { UploadResponseDto } from '../swagger/SwaggerGenerated';

export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL');
@Injectable({
  providedIn: 'root'
})
export class UploadService {
  /**
   *
   */
   private baseUrl: string;
  constructor(  private http: HttpClient,private toastr: ToastrService,@Optional() @Inject(API_BASE_URL) baseUrl?: string , 
  ) {
    this.baseUrl = 'http://localhost:4748'//baseUrl !== undefined && baseUrl !== null ? baseUrl : "";
  }
 
   UploadFile(docs) :Observable<HttpEvent<Object>>{
    let header = new HttpHeaders({
      // Referer: 'http://localhost:4200',
      // Origin: 'http://localhost:4200',
      Accept: '*/*',
    });
   return  this.http
      .post(this.baseUrl+routes.UploadLOADURL, docs, {
        headers: header,
        reportProgress: true,
        observe: 'events',
      })
      
  }
  DownloadFile(fileName,fileIdentifier){
    let url=`${this.baseUrl}${routes.DOWNLOADURL}?fileIdentifier=${fileIdentifier}&fileName=${fileName}`
    var downloadWindow = window.open(
      url,
      "_blank"
    );
    downloadWindow.focus();
    // return this.http.get(url, { reportProgress: true,
    //   responseType: 'blob' as 'json'}).subscribe(res=>{
    //     downloadFile(res)
    //     console.log(res)});
  }
}
