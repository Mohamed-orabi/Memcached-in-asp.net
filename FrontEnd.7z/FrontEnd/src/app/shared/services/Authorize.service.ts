import { Injectable } from '@angular/core'; 

@Injectable({
  providedIn: 'root',
})
export class AuthorizeService {
  pageActionObj: Array<number>=[];
  constructor() {
  
  }
  public isAuthorize(pageAction) {
    let pageaction = localStorage.getItem('PAS');
    if (pageaction) {
        this.pageActionObj=JSON.parse(pageaction);
    }
      debugger
      return this.pageActionObj.findIndex(x=>x==pageAction)>-1;
  }
}
