import { PageActionEnum } from './../../consts/PageActionEnum';
import { Component, OnInit } from '@angular/core';
import { routes } from '../../consts/routes';
import { AuthorizeService } from '../services/Authorize.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})

export class SidebarComponent implements OnInit {
  public routes: typeof routes = routes;
  public isOpenUiElements = false;
  showDashboard=false;
  showRequest=false;
  constructor(private authorizeService:AuthorizeService) {
   
  }
  ngOnInit(): void {
 this.showDashboard=true//this.authorizeService.isAuthorize(PageActionEnum.ViewDashboard)
 this.showRequest=true//this.authorizeService.isAuthorize(PageActionEnum.ViewRequest)
  }

  public openUiElements() {
    this.isOpenUiElements = !this.isOpenUiElements;
  }
}
