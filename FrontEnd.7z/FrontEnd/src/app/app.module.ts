import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';


import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { NotFoundComponent } from './module/not-found/not-found.component';
import { AppConfigService } from './shared/AppConfigService';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderInterceptor } from './shared/interceptors/loader.interceptor';
import { API_BASE_URL, QueryExecutorServiceProxy } from './shared/swagger/SwaggerGenerated';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AppLoaderComponent } from './shared/app-loader/app-loader.component';
import { NgxWebstorageModule } from 'ngx-webstorage';
import { CurrencyPipe } from '@angular/common';
import { NgxEchartsModule } from 'ngx-echarts';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { AuthorizeService } from './shared/services/Authorize.service';
import { QueryExceuterDashboardModule } from './module/query-exceuter-dashboard/query-exceuter-dashboard.module';
export function getApiBaseUrl(): string {
  return AppConfigService.appConfig.ApiBaseUrl;
}
@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,
    AppLoaderComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    MatSelectModule,
    SharedModule,
    // RequestModule,
    BrowserAnimationsModule,
    RouterModule,
    AppRoutingModule,
    ToastrModule.forRoot(),
    NgxWebstorageModule.forRoot(),
    QueryExceuterDashboardModule,
    MatCardModule,
    HttpClientModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    NgxEchartsModule.forRoot({
      echarts: () => import('echarts')
    })
  ],
  providers: [
    CurrencyPipe
    // , LoaderService, UploadService
    , { provide: API_BASE_URL, useFactory: getApiBaseUrl },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    AuthorizeService,
    QueryExecutorServiceProxy
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
