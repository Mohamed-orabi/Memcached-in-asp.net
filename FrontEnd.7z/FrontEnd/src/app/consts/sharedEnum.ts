export enum Action {
  Approve = 1,
  Declined = 2,
  Submitted = 3,
  ReActive = 4,
  Cancel = 5
}
export enum GroupType {
  Sales = 1,
  AFU = 2,
  POS = 3,
  Bank = 4,
  SalesSuperVisor = 5,
  SalesManager = 6,
  AFUSuperVisor = 7
}