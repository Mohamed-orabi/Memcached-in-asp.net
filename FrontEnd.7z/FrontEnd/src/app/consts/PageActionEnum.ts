export enum PageActionEnum {
  ViewDashboard = 1,
  ViewRequest = 2,
  AddRequest = 3,
  ExportRequest=6
//   EditRequest = 4,
//   DeleteRequest = 5,
}