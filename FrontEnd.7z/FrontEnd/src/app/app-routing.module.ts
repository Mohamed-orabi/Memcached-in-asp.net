import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { NotFoundComponent } from './module/not-found/not-found.component';
import { AuthGuard } from './shared/guards/auth.guard';
import { ListComponent } from './module/query-exceuter-dashboard/list/list.component';
    
const routes: Routes = [
  // {
  //   path: 'request',
  //   pathMatch: 'full',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./module/request/request.module').then(m => m.RequestModule)
  // },
  // {
  //   path: 'notification',
  //   pathMatch: 'full',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./module/notification/notification.module').then(m => m.NotificationModule)
  // },
  {
    path: '',
    pathMatch: 'full', 
    loadChildren: () => import('./module/query-exceuter-dashboard/query-exceuter-dashboard.module').then(m => m.QueryExceuterDashboardModule)
  },
  {
    path: '',
     component: ListComponent,
  },
  {
    path: '404',
    component: NotFoundComponent
  }, 
  {
    path: '**',
    redirectTo: '404'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: false,
      preloadingStrategy: PreloadAllModules,
      relativeLinkResolution: 'legacy'
    })
  ],
  exports: [RouterModule]
})

export class AppRoutingModule {
}
