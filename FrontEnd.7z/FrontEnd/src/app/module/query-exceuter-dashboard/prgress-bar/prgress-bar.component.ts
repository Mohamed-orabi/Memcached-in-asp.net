import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { QueryExecutorServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';
import { SignalrService } from '../signalr.service';

const incr = 1;

@Component({
  selector: 'app-prgress-bar',
  templateUrl: './prgress-bar.component.html',
  styleUrls: ['./prgress-bar.component.css']
})
export class PrgressBarComponent implements OnInit {

  @Input() idofJob:number = 0;
  progress = 0;
  constructor(private queryExecutorServiceProxy: QueryExecutorServiceProxy,
              private signalr : SignalrService) { }

  ngOnInit(): void {
     this.signalr.startConnection();
     this.signalr.getProgressBar();
     this.GetLongMethod();
     this.getData();
    //setInterval(() => this.manageProgress(), 150 )
  }

  manageProgress() {
    if(this.idofJob === 100) {
      this.idofJob = 0;
    } else {
      this.idofJob = this.idofJob + incr;
    }
  }

  private GetLongMethod(){
    this.queryExecutorServiceProxy.longMethod().subscribe(data => {
      console.log(data);
    });
  }

  getData(){
    this.signalr.SharingData.subscribe(data => {
      // console.log(data + "AA");
      this.idofJob = data;
    })
  }

}
