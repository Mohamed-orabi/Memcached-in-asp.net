import { Injectable } from '@angular/core';
import * as signalR from "@microsoft/signalr"
import { BehaviorSubject, Subject } from 'rxjs';
import { QueryExecutorServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';

@Injectable({
  providedIn: 'root'
})
export class SignalrService {

  //data:any;
  constructor() { }


  private hubConnection: signalR.HubConnection

  SharingData = new BehaviorSubject(0);
  

  public startConnection = () => {
    this.hubConnection = new signalR.HubConnectionBuilder()
                            .withUrl('https://localhost:44361/Progress')
                            .build();

    this.hubConnection
            .start()
            .then(() => console.log("Connection started"))
            .catch(err => console.log("Error while starting connection: " + err))
  }


  public getProgressBar =() => {
    this.hubConnection.on('TransferChartData',data => {
      //this.data = data;
      this.SharingData.next(data);
      //console.log(data);
    })

}

}
