import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { merge ,tap, debounceTime } from 'rxjs';
import { GetAllJobsSearchDTO, QueryExecutorServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';
import { BaseComponent } from '../../base.component';
import { Utils } from '../models/paging';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent extends BaseComponent implements OnInit,AfterViewInit {
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  
  form: FormGroup;
  idtest:number;
  idofJobofParent:number;
  resultsLength = 0;
  searchDto = {
  

    paging: {
      pageNumber: Utils.DEFUALT_PAGE_NUMBER,
      pageSize: Utils.DEFUALT_PAGE_SIZE
    },
    sortingModel: {
      sortingExpression: "",
      sortingDirection: 0
    },
    bankName: "",
    start:"",
    end: ""
  } as GetAllJobsSearchDTO;
  dataSource: any;
  displayedColumns: string[] = ['id', 'type', 'bankName', 'queryTotalCount', 'totalInsertedCount', 'failedInstertTotalCount', 'startRuntRun', 'endRuntRun', 'symbol','symbol2'];
  defualtPageSize: number = Utils.DEFUALT_PAGE_SIZE;
  
  
  constructor(
    private queryExecutorServiceProxy: QueryExecutorServiceProxy,
    private fb: FormBuilder
  ) { super() }



    ngAfterViewInit() {
    this.Sort();
  }

Sort(){
  this.sort.sortChange.subscribe();
  merge(this.sort.sortChange)
    .pipe(
      tap(() => {
        this.searchDto.sortingModel.direction = this.sort.direction;
        this.searchDto.sortingModel.column = this.sort.active;
         this.loadData();
      })
    )
    .subscribe();
}

SearrchDateRange(){
  this.form = this.fb.group({
    daterange: new FormGroup({
      start: new FormControl(),
      end: new FormControl(),
    }),
  });
}

  ngOnInit(): void {
    this.SearrchDataRange();
    this.loadData();
    this.getTotalCount();
  }

  onChangePage(pe: PageEvent) {
    console.log(pe);
    console.log(pe.length);
    console.log(pe.pageIndex);
    console.log(pe.pageSize);
    console.log(pe.previousPageIndex);
    console.log(this.dataSource.sort)
    this.searchDto.paging.pageNumber = pe.pageIndex;
    this.searchDto.paging.pageSize = pe.pageSize;
    //this.resultsLength = pe.length;
    this.loadData();
    return pe;
  }

  loadData() {
     this.queryExecutorServiceProxy.searchJobsTrackingPost(this.searchDto).subscribe(data =>{
       debugger
       this.dataSource = data.dataList;
       //this.resultsLength = data.totalCount;
       console.log(data);
     });
  }

  public Filter = (value: string) => {

    this.searchDto.bankName =value;
    this.loadData();
    this.queryExecutorServiceProxy.searchJobsTrackingGet().subscribe(data => 
    {
      let jobs = data.filter(function(bankName){
        return bankName.jobId === 2;
      });
      console.log(jobs);
      this.resultsLength = jobs.length;
    }) 
    console.log(this.searchDto);
  }

  getTotalCount(){
    this.queryExecutorServiceProxy.searchJobsTrackingGet().subscribe(data => {
      this.resultsLength = data.length;
    })
  }

  onSubmit(){
    this.searchDto.start = this.form.value.daterange['start'].toISOString().split('T')[0];
    this.searchDto.end = this.form.value.daterange['end'].toISOString().split('T')[0];
    this.loadData();
  }

  ProgressBarOfJob(id:number){
    this.queryExecutorServiceProxy.searchJobsTrackingGet().subscribe(data => {
      let id2 = data.find(x => x.id === id);
      if(data.includes(id2)){
        this.idofJobofParent = id2.id;
        this.idtest = id2.id;
        console.log(this.idtest);
      };
    });
    //console.log(id);
   
    //this.idofJobofParent = id;

  }

  

}
