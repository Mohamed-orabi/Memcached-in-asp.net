import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routes } from './consts/routes';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  /**
   *
   */
  constructor(private router: Router) {
    
  }
  ngOnInit(): void {
    // let token = window.location.hash.replace('#', '');
    // if (token) {
    //   window.localStorage.setItem('token', token);
    //   window.location.hash = '';
    // } else if (
    //   localStorage.getItem('token') == undefined ||
    //   localStorage.getItem('token') == null
    // ) {
    //   window.location.href = `${routes.SSOLOGIN}`;
    // } 
    // this.userServiceProxy.getUserInfo().subscribe((res) => {
    //   if (res) {  
    //     localStorage.setItem('PAS',JSON.stringify(res.pageActionId))
    //     localStorage.setItem('Name',res.name)
    //     localStorage.setItem('Group',res.groupName)

    //   }
    // }); 
  }
}
