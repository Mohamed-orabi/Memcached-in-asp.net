import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { NgxEchartsModule } from 'ngx-echarts';
import {MatDatepickerModule} from '@angular/material/datepicker';

import { TrendModule } from 'ngx-trend';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { NgApexchartsModule } from 'ng-apexcharts';
import { FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { MatStepperModule } from '@angular/material/stepper';
import {MatButtonToggleModule} from '@angular/material/button-toggle';

import { MatCheckboxModule } from '@angular/material/checkbox';
import { RouterModule, Routes } from '@angular/router';
 import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';
 import { HttpClientModule } from '@angular/common/http';
 import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldDefaultOptions, MatFormFieldModule, MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
 import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { NgxFormProgressBarModule } from 'ngx-form-progress-bar';
import { RequestContainerComponent } from './components/add-edit-request/request-container.component';
// import { NgxFormProgressBarModule } from 'ngx-form-progress-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import { MatDividerModule } from '@angular/material/divider';
import { MatRadioModule } from '@angular/material/radio';
import { lookupService } from 'dns';
// import { LookupServiceProxy, RequestServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';
import { RequestListComponent } from './components/request-list/request-list.component';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { TimeLineComponent } from './components/time-line/time-line.component';  
import { MatDialogModule } from '@angular/material/dialog';
import { UploadService } from 'src/app/shared/services/upload.service';
import { DashboardComponent } from '../dashboard/component/dashboard/dashboard.component';
import { AuthorizeService } from 'src/app/shared/services/Authorize.service';
 

const routes: Routes = [
  {
    path: 'request',
    component: RequestListComponent,
  } ,
  {
    path: 'addEditRequest/:requestId/:view',
    component: RequestContainerComponent,
  } 
]; 
const appearance: MatFormFieldDefaultOptions = {
  appearance: 'legacy'
};

@NgModule({
  declarations: [
    RequestContainerComponent,
    RequestListComponent,
    TimeLineComponent,
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    MatTableModule,
    NgxEchartsModule,
    MatRadioModule,
    TrendModule,
    MatCardModule, MatPaginatorModule, MatSortModule,MatDialogModule,
MatTableModule,
    MatNativeDateModule,
    HttpClientModule,
    MatStepperModule,    NgxDropzoneModule  
    ,MatDialogModule,
    MatIconModule,
    MatButtonToggleModule,
    MatStepperModule,
    MatMenuModule,
    MatButtonModule,
    MatCheckboxModule,
    MatProgressBarModule,
    MatToolbarModule,MatDividerModule,
    FormlyBootstrapModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatExpansionModule,
    MatGridListModule,
    MatSelectModule,
    NgxFormProgressBarModule,
    MatInputModule,
    NgApexchartsModule,
    FormsModule,
    SharedModule, ReactiveFormsModule
  ],
  exports: [
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: appearance
    },
    // LookupServiceProxy,RequestServiceProxy,// ... other providers like services,
    UploadService,
    AuthorizeService
  ],

})
export class RequestModule { }
