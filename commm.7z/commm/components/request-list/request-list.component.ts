import { routes } from './../../../../consts/routes'; 
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatExpansionPanel } from '@angular/material/expansion';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ActivatedRoute, Router } from '@angular/router';
import { merge, startWith, switchMap, map } from 'rxjs';
import { BaseComponent } from 'src/app/module/base.component';
import { TableUtil } from 'src/app/shared/services/tableUtil';
import { DDLDto, GetAllRequestInputDto, GetAllRequestOutputDto, LookupServiceProxy, RequestServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';
import { Utils } from '../../models/paging';
import { TimeLineComponent } from '../time-line/time-line.component';
import { ToastrService } from 'ngx-toastr';
import { AuthorizeService } from 'src/app/shared/services/Authorize.service';
import { PageActionEnum } from '../../../../consts/PageActionEnum';

@Component({
  selector: 'app-request-list',
  templateUrl: './request-list.component.html',
  styleUrls: ['./request-list.component.css']
})
export class RequestListComponent extends BaseComponent implements OnInit, AfterViewInit {
  @ViewChild('panel1') firstPanel: MatExpansionPanel;
  cityList: DDLDto[];
  userList: DDLDto[];
  stepList: DDLDto[];


  public toggleFirstPanel() {
    this.firstPanel.toggle();
  }
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  resultsLength = 0;
  dataSource: any;
  displayedColumns: string[] = ['Id', 'RequestName', 'CurrentState', 'City', 'SubmissionDate', 'SalesAgent', 'symbol'];
  displayedfilter: string[] = [];

  filterValues = {};
  filterSelectObj = [];
  Filters: boolean = false;
  defualtPageSize: number = Utils.DEFUALT_PAGE_SIZE;
  searchDto = {
    paging: {
      page: Utils.DEFUALT_PAGE_NUMBER,
      pageSize: Utils.DEFUALT_PAGE_SIZE
    },
    sortingModel: {
      sortingExpression: "",
      sortingDirection: 0
    },
    requestName: "",
    createdBy: 0,
    stateId: 0,
    cityId: 0,
    dateFrom: "",
    dateTo: ""
  }
  showAddBtn=false;
  showExportBtn=false;
  constructor(private requestService: RequestServiceProxy,
    private toastr:ToastrService, 
    private lookupService: LookupServiceProxy, 
    private authorizeService:AuthorizeService,
    private router: Router, public dialog: MatDialog) { super() }
    
  ngOnInit() {
    this.loadCityDDL()
    this.loadUserDDL()
    this.loadStepDDL()
    this.showAddBtn=this.authorizeService.isAuthorize(PageActionEnum.AddRequest);
    this.showExportBtn=this.authorizeService.isAuthorize(PageActionEnum.ExportRequest);
  }

  ngAfterViewInit() {
    this.loadData()
  }
  applyFilter(event: Event) {
    // const filterValue = (event.target as HTMLInputElement).value;
    // this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  resetSearch() {
    this.searchDto = {
      paging: {
        page: Utils.DEFUALT_PAGE_NUMBER,
        pageSize: Utils.DEFUALT_PAGE_SIZE
      },
      sortingModel: {
        sortingExpression: "",
        sortingDirection: 0
      },
      requestName: "",
      createdBy: 0,
      stateId: 0,
      cityId: 0,
      dateFrom: "",
      dateTo: ""

    }
    this.loadData()
  }
  testDate() {
       this.loadData()
  }
 
  exportTable() { 
    const onlyNameAndSymbolArr: Partial<GetAllRequestOutputDto>[] = this.dataSource.map(x => ({
      RequestName: x.requestName,
      City: x.cityName,
      CreatedDate: x.createdDate,
      CurrentState: x.currentState,
      CreatedBy: x.createdBy,
     }));


    TableUtil.exportArrayToExcel(onlyNameAndSymbolArr, "RequestList");
  }
  loadData() {
    debugger
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        startWith({}),
        switchMap(() => {

          this.prepareSearchObject(this.paginator, this.sort, this.searchDto);

          return this.requestService.getAllRequest(this.searchDto as GetAllRequestInputDto);
        }),
        map((data) => {
          // Flip flag to show that loading has finished.
          console.log(data);
          
          return data;
        }),
      )
      .subscribe((data) => {


        this.dataSource = data.dataList;
        this.resultsLength = data.totalCount;

      });
  }
  loadCityDDL() {

    this.lookupService.getCityDDL()
      .subscribe((data) => {
        if (data) {

          this.cityList = data
          //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
          // this.productForm.reset();
        }
      })

  }
  loadUserDDL() {

    this.lookupService.getUserForGroup()
      .subscribe((data) => {
        if (data) {

          this.userList = data
          //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
          // this.productForm.reset();
        }
      })

  }
  loadStepDDL() {

    this.lookupService.getRequestStep()
      .subscribe((data) => {
        if (data) {
debugger
          this.stepList = data
          //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
          // this.productForm.reset();
        }
      })

  }

  navigateToAddEditPage(requestId) {
    debugger
     // this.router.navigateByUrl(['/request/edit', ]);
    this.router.navigateByUrl(`${routes.AddEditRequest}/${requestId}/false`,
    { skipLocationChange: true });



  }

  openDialog(id: number) {
    debugger
    const dialogRef = this.dialog.open(TimeLineComponent, {
      data: {
        id: id
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


  navigateToViewPage(productId) {
    // this.router.navigate([`/EditProduct?id=${productId}`], { relativeTo: this.route });
    // this.router.navigateByUrl(['/request/edit', ]);
    //this.router.navigateByUrl(`/request/edit?id=${productId}&view=true`);

    this.router.navigateByUrl(`${routes.AddEditRequest}/${productId}/true`,
    { skipLocationChange: true });
    
  }

  openDialog2(templateRef) {
    let dialogRef = this.dialog.open(templateRef, {
      width: '300px'
    });




  }

  reActivate(id) {
    this.requestService.reActiveRequest(id)
    .subscribe((data) => {
      if (data.isValidResponse && data.dataList) {
        this.toastr.success(
          "Info",
          data.commandMessage)
        this.router.navigateByUrl(`/request`);
      }
      else
        this.toastr.success(
          "error",
          data.commandMessage)
    })
  }
}

