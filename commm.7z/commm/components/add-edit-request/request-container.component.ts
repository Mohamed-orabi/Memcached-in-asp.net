import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { BaseComponent } from 'src/app/module/base.component';
import { NotificationService } from 'src/app/shared/services/notification-service.service';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
// import {
//   AttachmentDto,
//   BranchDto,
//   CommentDto,
//   CreateRequestDto,
//   DDLDto,
//   LookupServiceProxy,
//   MdrDto,
//   OwnerDto,
//   RequestServiceProxy,
//   RequestSettlmentDto,
//   UpdateRequestDto,
//   UploadResponseDto,
// } from 'src/app/shared/swagger/SwaggerGenerated';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpClient, HttpEventType, HttpHeaders } from '@angular/common/http';
import { routes } from 'src/app/consts';
import { MatDialog } from '@angular/material/dialog';
import { Action, GroupType } from 'src/app/consts/sharedEnum';
import { UploadService } from 'src/app/shared/services/upload.service';
import { Observable, Subject } from 'rxjs';
// import { ExtensionGetDDLDto } from '../../../../shared/swagger/SwaggerGenerated';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-request-container',
  templateUrl: './request-container.component.html',
  styleUrls: ['./request-container.component.css'],
})
export class RequestContainerComponent extends BaseComponent implements OnInit {
  ngOnInit(): void {
    
  }
  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  // form: FormGroup;
  // isEditableNew: boolean = true;
  // ELEMENT_DATA_Owner: OwnerDto[] = [];
  // ELEMENT_DATA_Branch: BranchDto[] = [];
  // ELEMENT_DATA_MDR: MdrDto[] = [];
  // ELEMENT_DATA_Comment: CommentDto[] = [];
  // ELEMENT_DATA_Attachment: AttachmentDto[] = [];
  // selectedCheckBoxList = [];
  // action: typeof Action = Action;
  // group: typeof GroupType = GroupType;
  // fileExt = "application/pdf"
  // groupId: number;
  // readOnly = false;
  // resultsLength = 0;
  // rejectionReason: string;
  // dataSource = new MatTableDataSource<any>();
  // displayedColumnsOwner = ['name', 'passportId', 'contact', 'action'];
  // displayedColumnsComment = ['name', 'action'];
  // displayedColumnsBranch = [
  //   'name',
  //   'address',
  //   'manager',
  //   'contact',
  //   'numberOfTerminals',
  //   'action',
  // ];
  // displayedColumnsMDR = [
  //   'volume',
  //   'percentage',
  //   'channelTypeId',
  //   'cardTypeId',
  //   'min',
  //   'fixed',
  //   'max',
  //   'action',
  // ];
  // displayedColumnsAttachment = ['name', 'extensionId', 'file', 'createdDate', 'action'];
  // dataSourceBranch: MatTableDataSource<any>;
  // dataSourceMDR: MatTableDataSource<any>;
  // dataSourceAttachment: MatTableDataSource<any>;
  // dataSourceComment: MatTableDataSource<any>;
  // contractServices: DDLDto[];
  // settlmentTypes: DDLDto[];

  // banksList: DDLDto[];
  // cityList: DDLDto[];
  // CBEList: DDLDto[];
  // mccList: DDLDto[];
  // extenstionList: ExtensionGetDDLDto[];
  // channelList: DDLDto[];
  // CardTypeList: DDLDto[];
  // requestId: number;
  // // filefields
  // files: File[] = [];
  // formData = new FormData();
  // private notifyService: NotificationService;
  // public progress: number;
  // allowedAction: number[];
  constructor(
    // public dialog: MatDialog,

    // private toastr: ToastrService,
    // private router: Router,
    // private route: ActivatedRoute,
    // private fb: FormBuilder,
    // private requestService: RequestServiceProxy,
    // private lookupService: LookupServiceProxy,
    // private uploadService: UploadService
  ) {
    super();

    // this.readQueryParams();
  }
  // backToList() {
  //   // this.router.navigate([`/EditProduct?id=${productId}`], { relativeTo: this.route });
  //   // this.router.navigateByUrl(['/request/edit', ]);
  //   setTimeout(() => {
  //     this.router.navigateByUrl(`/request`);

  //   }, 200);
  // }
  // readQueryParams() {
  //   this.route.paramMap.subscribe((params) => {
  //     debugger;
  //     if (params.get('requestId') != null) {
  //       this.requestId = parseInt(params.get('requestId'));
  //       this.readOnly = params.get('view') == 'true';

  //       if (this.requestId) this.loadData(Number(this.requestId));
  //     }
  //   });
  // }
  // loadData(requestId: number) {
  //   if (this.requestId) {
  //     this.requestService.getRequestById(requestId).subscribe((res) => {
  //       if (res) {
  //         this.form.patchValue(res);
  //         this.allowedAction = res?.allowedActions;

  //         this.groupId = res?.groupId;

  //         if (res.owner.length > 0) {
  //           var control = this.form.get('owner') as FormArray;
  //           res.owner.forEach((element) => {
  //             control.insert(0, this.initiateOwnerForm(element));
  //             this.dataSource = new MatTableDataSource(
  //               control.controls.filter((u) => u.value.isDeleted != true)
  //             );
  //           });
  //         }

  //         if (res.mdr.length > 0) {
  //           var control = this.form.get('mdr') as FormArray;
  //           res.mdr.forEach((element) => {
  //             control.insert(0, this.initiateMDRForm(element));
  //             this.dataSourceMDR = new MatTableDataSource(
  //               control.controls.filter((u) => u.value.isDeleted != true)
  //             );
  //           });
  //         }

  //         if (res.attachement.length > 0) {
  //           var control = this.form.get('attachment') as FormArray;
  //           res.attachement.forEach((element) => {
  //             control.insert(0, this.initiateAttachmentForm(element));
  //             this.dataSourceAttachment = new MatTableDataSource(
  //               control.controls.filter((u) => u.value.isDeleted != true)
  //             );
  //           });
  //         }

  //         if (res.branch.length > 0) {
  //           var control = this.form.get('branch') as FormArray;
  //           res.branch.forEach((element) => {
  //             control.insert(0, this.initiateBranchForm(element));
  //             this.dataSourceBranch = new MatTableDataSource(
  //               control.controls.filter((u) => u.value.isDeleted != true)
  //             );
  //           });
  //         }

  //         if (res.comment.length > 0) {
  //           var control = this.form.get('comment') as FormArray;
  //           res.comment.forEach((element) => {
  //             control.insert(0, this.initiateCommentForm(element));
  //             this.dataSourceComment = new MatTableDataSource(
  //               control.controls.filter((u) => u.value.isDeleted != true)
  //             );
  //           });
  //         }
  //         if (res.contractedService.length > 0) {
  //           var control = this.form.get('contractedService') as FormArray;
  //           res.contractedService.forEach((element) => {
  //             // debugger
  //             // control.insert(0, (element as any));
  //             control.push(new FormControl(element));
  //             this.selectedCheckBoxList.push(element);
  //           });
  //         }

  //         if (res.settlmentType != undefined || res.settlmentType != null) {
  //           this.form
  //             .get('settlementTypeId')
  //             .setValue(res?.settlmentType?.settlementTypeId);
  //           this.form.get('bankId').setValue(res?.settlmentType?.bankId);
  //           this.form.get('iban').setValue(res?.settlmentType?.iban);
  //           this.form.get('swift').setValue(res?.settlmentType?.swift);
  //           this.form.get('name').setValue(res?.settlmentType?.name);
  //           this.form.get('typeNumber').setValue(res?.settlmentType?.number);
  //         }
  //       }
  //     });
  //   }
  // }

  // openDialog(templateRef) {
  //   let dialog = this.dialog.open(templateRef, {
  //     width: '300px',
  //   });
  // }
  // openRejectDialog(templateRef) {
  //   let dialog = this.dialog.open(templateRef, {
  //     width: '300px',
  //   });


  //   dialog.afterClosed().subscribe(result => {
  //     console.log('The dialog was closed');
  //   });

  // }
  // onCheckboxChange(e: any) {
  //   // debugger
  //   // const contractedService = (this.form.controls.contractedService as FormArray);
  //   // if (event.target.checked) {
  //   //   contractedService.push(new FormControl(event.target.value));
  //   // } else {
  //   //   const index = contractedService.controls
  //   //     .findIndex(x => x.value === event.target.value);
  //   //   contractedService.removeAt(index);
  //   // }

  //   const contractedService = this.form.controls.contractedService as FormArray;
  //   // debugger
  //   if (e.target.checked) {
  //     let selectedValue = parseInt(e.target.value);
  //     contractedService.push(new FormControl(selectedValue));
  //     this.selectedCheckBoxList.push(selectedValue);
  //   } else {
  //     const index = contractedService.controls.findIndex(
  //       (technology) => technology.value === parseInt(e.target.value)
  //     );
  //     contractedService.removeAt(index);
  //     const indexList = this.selectedCheckBoxList.findIndex(
  //       (technology) => technology === parseInt(e.target.value)
  //     );
  //     this.selectedCheckBoxList.splice(indexList, 1);
  //   }
  // }

  // ngOnInit() {
  //   this.form = this.fb.group({
  //     legalName: new FormControl('', Validators.required),
  //     address: new FormControl('', Validators.required),
  //     cityId: new FormControl('', Validators.required),
  //     cbeSegmentId: new FormControl('', Validators.required),
  //     mccId: new FormControl('', Validators.required),
  //     commercialNumber: new FormControl('', Validators.required),
  //     taxId: new FormControl('', Validators.required),
  //     commercialName: new FormControl('', Validators.required),
  //     contactPerson: new FormControl('', Validators.required),
  //     contactPersonPhone: new FormControl('', Validators.required),
  //     merchantActivityDescription: new FormControl('', Validators.required),
  //     website: new FormControl('', Validators.required),
  //     sameMId: new FormControl(false, []),
  //     settlementTypeId: new FormControl(1, Validators.required),

  //     typeNumber: new FormControl('', Validators.required),
  //     name: new FormControl(''),
  //     swift: new FormControl(''),
  //     iban: new FormControl(''),
  //     bankId: new FormControl(''),

  //     owner: this.fb.array([]), //end of fb array
  //     attachment: this.fb.array([]), //end of fb array

  //     branch: this.fb.array(
  //       []
  //       //   this.ELEMENT_DATA_Branch.map(val => this.fb.group({
  //       //   name: new FormControl(val.name, Validators.required),
  //       //   address: new FormControl(val.address, Validators.required),
  //       //   manager: new FormControl(val.manager, Validators.required),
  //       //   contact: new FormControl(val.contact, Validators.required),
  //       //   numberOfTerminals: new FormControl(val.numberOfTerminals, Validators.required),
  //       //   isDeleted: new FormControl(false),
  //       //   isEditable: new FormControl(true),
  //       //   isNewRow: new FormControl(false),
  //       // })
  //       // )
  //     ),
  //     comment: this.fb.array(
  //       []
  //       //   this.ELEMENT_DATA_Comment.map(val => this.fb.group({
  //       //   name: new FormControl(val.name, Validators.required),
  //       //   isDeleted: new FormControl(false),
  //       //   isEditable: new FormControl(true),
  //       //   isNewRow: new FormControl(false),
  //       // })
  //       // )
  //     ),
  //     mdr: this.fb.array(
  //       []
  //       //   this.ELEMENT_DATA_MDR.map(val => this.fb.group({
  //       //   volume: new FormControl(val.volume, Validators.required),
  //       //   percentage: new FormControl(val.percentage, Validators.required),
  //       //   channelTypeId: new FormControl(val.channelTypeId, Validators.required),
  //       //   cardTypeId: new FormControl(val.cardTypeId, Validators.required),
  //       //   isDeleted: new FormControl(false),
  //       //   isEditable: new FormControl(true),
  //       //   isNewRow: new FormControl(false),
  //       // })
  //       // )
  //     ),
  //     contractedService: new FormArray([]),
  //   }); // end of form group cretation

  //   // this.dataSource = new MatTableDataSource((this.form.get('owner') as FormArray).controls);

  //   this.setSettlmentValidators(this.form.get('settlementTypeId').value);

  //   this.loadBanksDDL();
  //   this.loadCityDDL();
  //   this.loadCBESegmentDDL();
  //   this.loadMCCDDL();
  //   this.loadExtenstionDDL();
  //   this.loadContractServicesDDL();
  //   this.loadChannelServicesDDL();
  //   this.loadCardTypeServicesDDL();
  //   this.loadSettelmentServicesDDL();
  //   debugger;

  //   if (this.readOnly) this.form.disable();
  // }

  // // files

  // // On file Select
  // onFileChange(event, index) {
  //   debugger;
  //   if (event.target.files[0].type != this.fileExt) {
  //     this.toastr.error("Attached document type not matched with selected type", "")
  //     return;
  //   } else {
  //     let orignalName = event.target.files[0].name;
  //     this.formData.set(
  //       'file',
  //       event.target.files[0],
  //       event.target.files[0].name
  //     );
  //     this.uploadService.UploadFile(this.formData).subscribe((event) => {
  //       debugger;
  //       if (event.type === HttpEventType.Response) {
  //         if (event.status == 200) {
  //           debugger;
  //           //  event.body as UploadResponseDto[];
  //           (this.form.get('attachment') as FormArray)
  //             .at(index)
  //             .get('identifier')
  //             .patchValue((event.body as UploadResponseDto[])[0].fileIdentifier);
  //           (this.form.get('attachment') as FormArray)
  //             .at(index)
  //             .get('originalName')
  //             .patchValue(orignalName);
  //         } else {
  //           this.toastr.error('Cannot Attach Document');
  //           false;
  //         }
  //       }
  //     });
  //   }

  // }

  // Download(VOFormElement, i) {
  //   // debugger
  //   this.uploadService.DownloadFile(
  //     VOFormElement.get('attachment').at(i).get('name').value + '.' +
  //     VOFormElement.get('attachment').at(i).get('originalName').value.split('.')[1],
  //     VOFormElement.get('attachment').at(i).get('identifier').value
  //   );
  //   console.log(VOFormElement.get('attachment').at(i).get('identifier').value);
  // }

  // updateStatus(attachments: AttachmentDto[]) {
  //   // this.requestService.updateRequest(
  //   // attachment?=attachments
  //   // )
  // }

  // loadBanksDDL() {
  //   this.lookupService.getBankDDL().subscribe((data) => {
  //     if (data) {
  //       this.banksList = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }

  // loadCityDDL() {
  //   this.lookupService.getCityDDL().subscribe((data) => {
  //     if (data) {
  //       this.cityList = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }

  // loadCBESegmentDDL() {
  //   this.lookupService.getCbeSegmentDDL().subscribe((data) => {
  //     if (data) {
  //       this.CBEList = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }
  // loadMCCDDL() {
  //   this.lookupService.getMccDDL().subscribe((data) => {
  //     if (data) {
  //       this.mccList = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }
  // loadExtenstionDDL() {
  //   this.lookupService.getExtensionDDL().subscribe((data) => {
  //     if (data) {
  //       this.extenstionList = data;
  //       this.fileExt = data[0].type
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }
  // loadContractServicesDDL() {
  //   this.lookupService.getContractedServiceDDL().subscribe((data) => {
  //     if (data) {
  //       this.contractServices = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }

  // loadChannelServicesDDL() {
  //   this.lookupService.getChannelTypeDDL().subscribe((data) => {
  //     if (data) {
  //       this.channelList = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }
  // loadCardTypeServicesDDL() {
  //   this.lookupService.getCardTypeDDL().subscribe((data) => {
  //     if (data) {
  //       this.CardTypeList = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }
  // loadSettelmentServicesDDL() {
  //   this.lookupService.getSettlmentDDL().subscribe((data) => {
  //     if (data) {
  //       this.settlmentTypes = data;
  //       //this.router.navigateByUrl('dashboard/saving', { state: { user: this.jsonObj } })
  //       // this.productForm.reset();
  //     }
  //   });
  // }

  // setSettlmentValidators(typeId) {
  //   const bankControl = this.form.get('bankId');
  //   const ibanControl = this.form.get('iban');
  //   const swiftControl = this.form.get('swift');
  //   const nameControl = this.form.get('name');
  //   // debugger
  //   if (typeId === 1) {
  //     nameControl.setValidators([Validators.required]);
  //     bankControl.setValidators([Validators.required]);
  //     swiftControl.setValidators([Validators.required]);
  //     ibanControl.setValidators([Validators.required]);
  //   }

  //   if (typeId === 2) {
  //     nameControl.setValidators(null);
  //     bankControl.setValidators(null);
  //     swiftControl.setValidators(null);
  //     ibanControl.setValidators(null);
  //     nameControl.setValue(null);
  //     bankControl.setValue(null);
  //     swiftControl.setValue(null);
  //     ibanControl.setValue(null);
  //   }
  //   if (typeId === 3) {
  //     bankControl.setValidators([Validators.required]);

  //     nameControl.setValidators(null);
  //     swiftControl.setValidators(null);
  //     ibanControl.setValidators(null);
  //     nameControl.setValue(null);
  //     bankControl.setValue(null);
  //     swiftControl.setValue(null);
  //     ibanControl.setValue(null);
  //   }

  //   bankControl.updateValueAndValidity();
  //   ibanControl.updateValueAndValidity();
  //   swiftControl.updateValueAndValidity();
  //   nameControl.updateValueAndValidity();
  // }
  // onSubmit() {
  //   if (this.requestId > 0) {
  //     //update the request
  //     var updateRequestDto = this.form.value as UpdateRequestDto;
  //     updateRequestDto.id = this.requestId;
  //     updateRequestDto.contractService = this.selectedCheckBoxList;
  //     updateRequestDto.requestSettlementData = new RequestSettlmentDto();
  //     updateRequestDto.requestSettlementData.bankId = this.form.value.bankId;
  //     updateRequestDto.requestSettlementData.iban = this.form.value.iban;
  //     updateRequestDto.requestSettlementData.swift = this.form.value.swift;
  //     updateRequestDto.requestSettlementData.name = this.form.value.name;
  //     updateRequestDto.requestSettlementData.number =
  //       this.form.value.typeNumber;
  //     updateRequestDto.requestSettlementData.settlementTypeId =
  //       this.form.value.settlementTypeId;
  //     debugger;
  //     this.requestService.updateRequest(updateRequestDto).subscribe((data) => {
  //       if (data.isValidResponse) {
  //         this.toastr.success('Info', 'Request Updated Successfully');

  //         this.router.navigateByUrl('request');
  //       }
  //     });
  //   } else {
  //     //this.upload();

  //     var createRequestDto = this.form.value as CreateRequestDto;
  //     createRequestDto.requestSettlementData = new RequestSettlmentDto();
  //     createRequestDto.requestSettlementData.bankId = this.form.value.bankId;
  //     createRequestDto.requestSettlementData.iban = this.form.value.iban;
  //     createRequestDto.requestSettlementData.swift = this.form.value.swift;
  //     createRequestDto.requestSettlementData.name = this.form.value.name;
  //     createRequestDto.requestSettlementData.number =
  //       this.form.value.typeNumber;
  //     createRequestDto.requestSettlementData.settlementTypeId =
  //       this.form.value.settlementTypeId;
  //     createRequestDto.contractService = this.selectedCheckBoxList;

  //     debugger;
  //     this.requestService.createRequest(createRequestDto).subscribe((data) => {
  //       if (data.isValidResponse) {
  //         this.toastr.success('Info', 'Request Added Successfully');

  //         this.router.navigateByUrl('request');
  //       }
  //     });
  //   }
  // }

  // //#region DynamicLists

  // get(data) {
  //   // debugger
  //   if (data.value == 'indCust') {
  //     console.log(data);
  //   } else {
  //   }
  // }

  // initiateOwnerForm(element): FormGroup {
  //   return this.fb.group({
  //     id: new FormControl(element?.id > 0 ? element?.id : 0),
  //     name: new FormControl(
  //       element?.name ? element?.name : '',
  //       Validators.required
  //     ),
  //     passportId: new FormControl(
  //       element?.passportId ? element?.passportId : '',
  //       Validators.required
  //     ),
  //     contact: new FormControl(
  //       element?.contact ? element?.contact : '',
  //       Validators.required
  //     ),
  //     isDeleted: new FormControl(false),
  //     isNewRow: new FormControl(element?.id > 0 ? false : true),
  //     action: new FormControl(element?.id > 0 ? 'editOld' : 'newRecord'),
  //     isEditable: new FormControl(element?.id > 0 ? true : false),
  //   });
  // }

  // initiateBranchForm(element): FormGroup {
  //   return this.fb.group({
  //     id: new FormControl(element?.id > 0 ? element?.id : 0),
  //     name: new FormControl(
  //       element?.name ? element?.name : '',
  //       Validators.required
  //     ),
  //     address: new FormControl(
  //       element?.address ? element.address : '',
  //       Validators.required
  //     ),
  //     manager: new FormControl(
  //       element?.manager ? element?.manager : '',
  //       Validators.required
  //     ),
  //     contact: new FormControl(
  //       element?.contact ? element?.contact : '',
  //       Validators.required
  //     ),
  //     numberOfTerminals: new FormControl(
  //       element?.numberOfTerminals ? element?.numberOfTerminals : '',
  //       Validators.required
  //     ),
  //     isDeleted: new FormControl(false),
  //     isNewRow: new FormControl(element?.id > 0 ? false : true),
  //     action: new FormControl(element?.id > 0 ? 'editOld' : 'newRecord'),
  //     isEditable: new FormControl(element?.id > 0 ? true : false),
  //   });
  // }

  // controlOnChange(e) {
  //   const technologies: FormArray = this.form.get('technology') as FormArray;

  //   if (e.target.checked) {
  //     technologies.push(new FormControl(e.target.value));
  //     this.selectedCheckBoxList.push(e.target.value);
  //   } else {
  //     const index = technologies.controls.findIndex(
  //       (technology) => technology.value === e.target.value
  //     );
  //     technologies.removeAt(index);
  //   }
  // }

  // ExtChange(event) {
  //   this.fileExt = this.extenstionList.filter(x => x.id == event)[0].type
  // }
  // initiateCommentForm(element): FormGroup {
  //   return this.fb.group({
  //     id: new FormControl(element?.id > 0 ? element?.id : 0),
  //     name: new FormControl(
  //       element?.name ? element?.name : '',
  //       Validators.required
  //     ),
  //     isDeleted: new FormControl(false),
  //     isNewRow: new FormControl(element?.id > 0 ? false : true),
  //     action: new FormControl(element?.id > 0 ? 'editOld' : 'newRecord'),
  //     isEditable: new FormControl(element?.id > 0 ? true : false),
  //   });
  // }
  // initiateAttachmentForm(element): FormGroup {
  //   return this.fb.group({
  //     id: new FormControl(element?.id > 0 ? element?.id : 0),
  //     name: new FormControl(
  //       element?.name ? element?.name : '',
  //       Validators.required
  //     ),
  //     extensionId: new FormControl(
  //       element?.extensionId ? element?.extensionId : 1,
  //       Validators.required
  //     ),
  //     identifier: new FormControl(
  //       element?.identifier ? element?.identifier : '',
  //       Validators.required
  //     ),
  //     originalName: new FormControl(
  //       element?.originalName ? element?.originalName : ''
  //     ),
  //     createdDate: new FormControl(
  //       element?.createdDate ? formatDate(element.createdDate, 'yyy-MM-dd', 'en') :
  //         formatDate(new Date, 'yyy-MM-dd', 'en')
  //     ),
  //     isDeleted: new FormControl(false),
  //     isNewRow: false, // new FormControl(element?.id > 0 ? false : true),
  //     action: new FormControl(element?.id > 0 ? 'editOld' : 'newRecord'),
  //     isEditable: false, // new FormControl(element?.id > 0 ? true : false),
  //   });
  // }
  // initiateMDRForm(element): FormGroup {
  //   return this.fb.group({
  //     id: new FormControl(element?.id > 0 ? element?.id : 0),
  //     volume: new FormControl(
  //       element?.volume ? element?.volume : '',
  //       Validators.required
  //     ),
  //     percentage: new FormControl(
  //       element?.percentage ? element?.percentage : '',
  //       Validators.required
  //     ),
  //     channelTypeId: new FormControl(
  //       element?.channelTypeId ? element?.channelTypeId : '',
  //       Validators.required
  //     ),
  //     cardTypeId: new FormControl(
  //       element?.cardTypeId ? element?.cardTypeId : '',
  //       Validators.required
  //     ),
  //     min: new FormControl(
  //       element?.min ? element?.min : '',
  //       Validators.required
  //     ),
  //     fixed: new FormControl(
  //       element?.fixed ? element?.fixed : '',
  //       Validators.required
  //     ),
  //     max: new FormControl(
  //       element?.max ? element?.max : '',
  //       Validators.required
  //     ),
  //     isDeleted: new FormControl(false),
  //     isNewRow: new FormControl(element?.id > 0 ? false : true),
  //     action: new FormControl(element?.id > 0 ? 'editOld' : 'newRecord'),
  //     isEditable: new FormControl(element?.id > 0 ? true : false),
  //   });
  // }

  // add(type) {
  //   var control;
  //   switch (type) {
  //     case 'owner':
  //       control = this.form.get('owner') as FormArray;
  //       control.insert(0, this.initiateOwnerForm(null));
  //       this.dataSource = new MatTableDataSource(
  //         control.controls.filter((u) => u.value.isDeleted != true)
  //       );
  //       break;

  //     case 'branch':
  //       control = this.form.get('branch') as FormArray;
  //       control.insert(0, this.initiateBranchForm(null));
  //       this.dataSourceBranch = new MatTableDataSource(
  //         control.controls.filter((u) => u.value.isDeleted != true)
  //       );
  //       break;

  //     case 'mdr':
  //       control = this.form.get('mdr') as FormArray;
  //       control.insert(0, this.initiateMDRForm(null));
  //       this.dataSourceMDR = new MatTableDataSource(
  //         control.controls.filter((u) => u.value.isDeleted != true)
  //       );
  //       break;
  //     case 'attachment':
  //       control = this.form.get('attachment') as FormArray;
  //       control.insert(0, this.initiateAttachmentForm(null));
  //       this.dataSourceAttachment = new MatTableDataSource(
  //         control.controls.filter((u) => u.value.isDeleted != true)
  //       );
  //       break;
  //     case 'comment':
  //       control = this.form.get('comment') as FormArray;
  //       control.insert(0, this.initiateCommentForm(null));
  //       this.dataSourceComment = new MatTableDataSource(
  //         control.controls.filter((u) => u.value.isDeleted != true)
  //       );
  //       break;

  //     default:
  //       break;
  //   }
  // }

  // Edit(type, VOFormElement, i) {
  //   // VOFormElement.get('owner').at(i).get('name').disabled(false)
  //   // this.isEditableNew = true;
  //   switch (type) {
  //     case 'owner':
  //       VOFormElement.get('owner').at(i).get('isEditable').patchValue(false);

  //       break;

  //     case 'branch':
  //       VOFormElement.get('branch').at(i).get('isEditable').patchValue(false);

  //       break;

  //     case 'mdr':
  //       VOFormElement.get('mdr').at(i).get('isEditable').patchValue(false);

  //       break;
  //     case 'attachment':
  //       VOFormElement.get('attachment')
  //         .at(i)
  //         .get('isEditable')
  //         .patchValue(false);

  //       break;
  //     case 'comment':
  //       VOFormElement.get('comment').at(i).get('isEditable').patchValue(false);

  //       break;

  //     default:
  //       break;
  //   }
  // }
  // Delete(type, VOFormElement, i) {
  //   var control;
  //   switch (type) {
  //     case 'owner':
  //       control = <FormArray>this.form.get('owner');
  //       control.removeAt(i);
  //       this.dataSource = new MatTableDataSource(
  //         (this.form.get('owner') as FormArray).controls
  //       );
  //       break;

  //     case 'branch':
  //       control = <FormArray>this.form.get('branch');
  //       control.removeAt(i);
  //       this.dataSourceBranch = new MatTableDataSource(
  //         (this.form.get('branch') as FormArray).controls
  //       );
  //       break;

  //     case 'mdr':
  //       control = <FormArray>this.form.get('mdr');
  //       control.removeAt(i);
  //       this.dataSourceMDR = new MatTableDataSource(
  //         (this.form.get('mdr') as FormArray).controls
  //       );
  //       break;
  //     case 'attachment':
  //       control = <FormArray>this.form.get('attachment');
  //       control.removeAt(i);
  //       this.dataSourceAttachment = new MatTableDataSource(
  //         (this.form.get('attachment') as FormArray).controls
  //       );
  //       break;
  //     case 'comment':
  //       control = <FormArray>this.form.get('comment');
  //       control.removeAt(i);
  //       this.dataSourceComment = new MatTableDataSource(
  //         (this.form.get('comment') as FormArray).controls
  //       );
  //       break;

  //     default:
  //       break;
  //   }
  // }
  // // On click of correct button in table (after click on edit) this method will call
  // Save(type, VOFormElement, i) {
  //   // debugger
  //   // alert('SaveOwner')
  //   switch (type) {
  //     case 'owner':
  //       VOFormElement.get('owner').at(i).get('isEditable').patchValue(true);
  //       break;
  //     case 'branch':
  //       VOFormElement.get('branch').at(i).get('isEditable').patchValue(true);
  //       break;
  //     case 'mdr':
  //       VOFormElement.get('mdr').at(i).get('isEditable').patchValue(true);
  //       break;
  //     case 'attachment':
  //       VOFormElement.get('attachment')
  //         .at(i)
  //         .get('action')
  //         .patchValue('editOld');
  //       break;
  //     case 'comment':
  //       VOFormElement.get('comment').at(i).get('isEditable').patchValue(true);
  //       break;

  //     default:
  //       break;
  //   }
  // }

  // changeStatus(id) {
  //   debugger
  //   switch (id) {
  //     case Action.Approve:
  //       this.requestService.approveRequest(this.requestId).subscribe((data) => {
  //         if (data.isValidResponse) {
  //           this.toastr.success('Info', data.commandMessage);
  //         } else this.toastr.success('error', data.commandMessage);
  //       });
  //       break;
  //     case Action.Declined:
  //       if (this.rejectionReason != "") {
  //         this.requestService
  //         .declineRequest(this.requestId, this.rejectionReason)
  //         .subscribe((data) => {
  //           if (data.isValidResponse) {
  //             this.toastr.success('Info', data.commandMessage);
  //             debugger
  //           } else this.toastr.success('error', data.commandMessage);
  //         });
  //         }
  //         break;
  //     case Action.Cancel:
  //       if (this.rejectionReason != "") {
  //         this.requestService
  //           .cancelRequest(this.requestId, this.rejectionReason)
  //           .subscribe((data) => {
  //             if (data.isValidResponse) {
  //               this.toastr.success('Info', data.commandMessage);
  //               debugger
  //             } else this.toastr.success('error', data.commandMessage);
  //           });
  //       }

  //     default:
  //       break;


  //   }
  //   this.backToList()


  // }
}

//#region Owner Models
// const ELEMENT_DATA_Owner: any[] = [];
// const ELEMENT_DATA_Branch: any[] = [];
// const ELEMENT_DATA_MDR: any[] = [];
// const ELEMENT_DATA_Comment: any[] = [];
// const ELEMENT_DATA_Attachment: any[] = [];
//#endregion
