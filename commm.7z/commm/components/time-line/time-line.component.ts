import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AnyARecord } from 'dns';
import { GetTrackingDto, LookupServiceProxy, RequestServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';
export interface DialogData {
  id: number;
}

@Component({
  selector: 'app-time-line',
  templateUrl: './time-line.component.html',
  styleUrls: ['./time-line.component.css']
})

export class TimeLineComponent implements OnInit {
  timeLineList?:GetTrackingDto[];

  constructor(private timeService:RequestServiceProxy,@Inject(MAT_DIALOG_DATA) public data: DialogData,  ) { }


  
  ngOnInit(): void {
     this.timeService.getRequestTimeline(this.data.id).subscribe(res=>{


      console.log(res);
       this.timeLineList=res;
    
    })

  }

}
