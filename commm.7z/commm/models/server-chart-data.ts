export interface ServerChartData {
  firstServerChartData: number[],
  firstDataTitle: string,
  secondServerChartData: number[],
  secondDataTitle: string,
  thirdServerChartData: number[],
  thirdDataTitle: string,
  dates: string[]
}
