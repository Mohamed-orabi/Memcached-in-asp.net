﻿using System;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string key = textBox1.Text;
            string plain_Text = textBox2.Text;
            textBox5.Text = AesOperation.EncryptString(key, plain_Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string key = textBox3.Text;
            string cipher_text = textBox4.Text;
            textBox6.Text = AesOperation.DecryptString(key, cipher_text);
        }

    }
}
