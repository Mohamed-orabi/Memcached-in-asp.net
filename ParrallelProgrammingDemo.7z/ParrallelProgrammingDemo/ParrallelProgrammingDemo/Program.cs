﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ParrallelProgrammingDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTime dateTimeBefore = DateTime.Now;
            new Program().run();
            DateTime dateTimeAfter = DateTime.Now;
            TimeSpan timeSpan = dateTimeAfter.Subtract(dateTimeBefore);
            Console.WriteLine($"Total time for operations to complete took {timeSpan.Seconds} {(timeSpan.Seconds > 1 ? "seconds" : "second")}");
            Console.ReadLine();
        }
        private void run()
        {
            // For demo purposes, cancel after a couple of seconds.

            using (var fileWriter = new ParallelFileWriter(@"D:\Orabi\Logs\file3.txt", 2))
            using (var cancellationSource = new CancellationTokenSource(2000))
            {
                const int NUM_THREADS = 5;
                Action[] actions = new Action[NUM_THREADS];

                for (int i = 0; i < NUM_THREADS; ++i)
                {
                    int id = i;
                    actions[i] = () => writer(cancellationSource.Token, fileWriter, id);
                }

                Parallel.Invoke(actions);
            }
        }

        private void writer(CancellationToken cancellation, ParallelFileWriter fileWriter, int id)
        {
            StringBuilder Sb = new StringBuilder();
            Sb.AppendLine($"DoSomeTask started by Thread {Thread.CurrentThread.ManagedThreadId}");
            //Thread.Sleep(1000);
            Sb.AppendLine($"DoSomeTask completed by Thread {Thread.CurrentThread.ManagedThreadId}");
            //string text = $"DoSomeTask started by Thread {Thread.CurrentThread.ManagedThreadId}";
            //fileWriter.Write(text);
            //string text2 = $"DoSomeTask completed by Thread {Thread.CurrentThread.ManagedThreadId}";
            fileWriter.Write(Sb.ToString());

        }

        //public static string DoTask()
        //{
        //    ParallelFileWriter parallelFileWriter = new ParallelFileWriter();
        //    parallelFileWriter.Write($"Number thread { Thread.CurrentThread.ManagedThreadId}");
        //    return $"Number thread {Thread.CurrentThread.ManagedThreadId}";
        //}


    }

    public sealed class ParallelFileWriter : IDisposable
    {
        // maxQueueSize is the maximum number of buffers you want in the queue at once.
        // If this value is reached, any threads calling Write() will block until there's
        // room in the queue.

        public ParallelFileWriter(string filename, int maxQueueSize)
        {
            _stream = new FileStream(filename, FileMode.Create);
            _queue = new BlockingCollection<string>(maxQueueSize);
            _writerTask = Task.Run(() => writerTask());
        }

        public void Write(string data)
        {
            _queue.Add(data);
        }

        public void Dispose()
        {
            _queue.CompleteAdding();
            _writerTask.Wait();
            _stream.Close();
        }

        private void writerTask()
        {
            foreach (var data in _queue.GetConsumingEnumerable())
            {
                Debug.WriteLine("Queue size = {0}", _queue.Count);
                byte[] bytes = Encoding.UTF8.GetBytes(data);
                _stream.Write(bytes, 0, bytes.Length);
            }
        }

        private readonly Task _writerTask;
        private readonly BlockingCollection<string> _queue;
        private readonly FileStream _stream;
    }
    //public sealed class ParallelFileWriter : IDisposable
    //{
    //    private readonly Task _writerTask;
    //    private readonly BlockingCollection<string> _queue;


    //    public ParallelFileWriter()
    //    {

    //        _queue = new BlockingCollection<string>(boundedCapacity:5);
    //        _writerTask = Task.Run(() => writerTask());
    //    }

    //    public void Write(string data)
    //    {
    //        _queue.Add(data);
    //    }

    //    public void Dispose()
    //    {
    //        _queue.CompleteAdding();
    //        _writerTask.Wait();
    //    }

    //    private void writerTask()
    //    {
    //        foreach (var data in _queue.GetConsumingEnumerable())
    //        {

    //                //using StreamWriter sw = File.AppendText(@"D:\Orabi\Logs\file3.txt");
    //                using FileStream sw2 = File.Open(@"D:\Orabi\Logs\file3.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
    //                byte[] bytes = Encoding.UTF8.GetBytes(data);
    //                sw2.Write(bytes, 0, bytes.Length);

    //            //Console.WriteLine($"Number thread { Thread.CurrentThread.ManagedThreadId}");
    //        }
    //    }

    //}
}