﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ParrallelProgrammingDemo
{
    public class DemoOne
    {
        static void DoSomeTask2(CancellationToken cancellation)
        {
            ParallelFileWriter2 parallelFileWriter2 = new ParallelFileWriter2("", 5);
            int index = 0;
            parallelFileWriter2.Write($"Mohamed{index}");
        }

        public sealed class ParallelFileWriter2 : IDisposable
        {
            private readonly Task _writerTask;
            private readonly BlockingCollection<string> _queue;
            private readonly FileStream _stream;



            public ParallelFileWriter2(string filename, int maxQueueSize)
            {
                _queue = new BlockingCollection<string>(maxQueueSize);
                _writerTask = Task.Run(() => writerTask());
                _stream = new FileStream(filename, FileMode.Append);
            }

            public void Write(string data)
            {
                _queue.Add(data);
                Console.WriteLine("data");
            }

            public void Dispose()
            {
                _queue.CompleteAdding();
                _writerTask.Wait();
                _stream.Close();
            }

            private void writerTask()
            {
                foreach (var data in _queue.GetConsumingEnumerable())
                {
                    int index = 0;
                    //using StreamWriter sw = File.AppendText(myfile);
                    //sw.WriteLine($"DoSomeTask {data} - {index++} started by Thread {Thread.CurrentThread.ManagedThreadId}");
                    byte[] data2 = Encoding.UTF8.GetBytes(data);
                    _stream.Write(data2);
                }
            }
        }
        private void PP()
        {
            DateTime dateTimeBefore = DateTime.Now;

            ParallelOptions parallelOptions = new ParallelOptions
            {
                MaxDegreeOfParallelism = 4
            };

            Parallel.Invoke(
                    () => DoSomeTask(1),
                    () => DoSomeTask(2),
                    () => DoSomeTask(3),
                    () => DoSomeTask(4),
                    () => DoSomeTask(6),
                    () => DoSomeTask(7)
                );

            DateTime dateTimeAfter = DateTime.Now;
            TimeSpan timeSpan = dateTimeAfter.Subtract(dateTimeBefore);
            Console.WriteLine($"Total time for operations to complete took {timeSpan.Seconds} {(timeSpan.Seconds > 1 ? "seconds" : "second")}");
        }
        static void DoSomeTask(int number)
        {
            lock ("")
            {
                using StreamWriter sw = File.AppendText("");
                sw.WriteLine($"DoSomeTask {number} started by Thread {Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(5000);
                sw.WriteLine($"DoSomeTask {number} completed by Thread {Thread.CurrentThread.ManagedThreadId}");
            }
        }

        private void run()
        {
            // For demo purposes, cancel after a couple of seconds.

            using (var fileWriter = new ParallelFileWriter("", 5))
            using (var cancellationSource = new CancellationTokenSource(2000))
            {
                const int NUM_THREADS = 8;
                Action[] actions = new Action[NUM_THREADS];

                for (int i = 0; i < NUM_THREADS; ++i)
                {
                    int idofThread = i;
                    actions[i] = () => writer(cancellationSource.Token, fileWriter, "Mohamed");
                }

                Parallel.Invoke(actions);
            }
        }

        private void writer(CancellationToken cancellation, ParallelFileWriter fileWriter, string name)
        {
            int index = 0;

            while (!cancellation.IsCancellationRequested)
            {
                string text = string.Format("{0}:{1}\n", "Thread Number " + Thread.CurrentThread.ManagedThreadId, name);
                //byte[] data = Encoding.UTF8.GetBytes(text);
                fileWriter.Write(text);
            }
        }



        static void DoSomeTaskWithException(int number)
        {
            using StreamWriter sw = File.AppendText("");
            sw.WriteLine($"DoSomeTask {number} started by Thread {Thread.CurrentThread.ManagedThreadId}");
            throw new Exception("Hi");
        }

        /*
         ParallelOptions parallelOptions = new ParallelOptions
            {
                MaxDegreeOfParallelism = 4
            };

            Parallel.Invoke(parallelOptions,
                    () => DoSomeTask(1),
                    () => DoSomeTask(2),
                    () => DoSomeTask(3),
                    () => DoSomeTask(4),
                    () => DoSomeTask(5),
                    () => DoSomeTask(6),
                    () => DoSomeTask(7)
                );


         static void DoSomeTask(int number)
        {
            Console.WriteLine($"DoSomeTask {number} started by Thread {Thread.CurrentThread.ManagedThreadId}");
            //Sleep for 5000 milliseconds
            Thread.Sleep(5000);
            Console.WriteLine($"DoSomeTask {number} completed by Thread {Thread.CurrentThread.ManagedThreadId}");
        }
         */
    }

    public sealed class ParallelFileWriter : IDisposable
    {
        private readonly Task _writerTask;
        private readonly BlockingCollection<string> _queue;
        private readonly FileStream _stream;


        public ParallelFileWriter(string filename, int maxQueueSize)
        {
            _stream = new FileStream(filename, FileMode.Create);
            _queue = new BlockingCollection<string>(maxQueueSize);
            _writerTask = Task.Run(() => writerTask());
        }

        public void Write(string data)
        {
            _queue.Add(data);
        }

        public void Dispose()
        {
            _queue.CompleteAdding();
            _writerTask.Wait();
            _stream.Close();
        }

        private void writerTask()
        {
            foreach (var data in _queue.GetConsumingEnumerable())
            {
                Debug.WriteLine("Queue size = {0}", _queue.Count);
                byte[] data2 = Encoding.UTF8.GetBytes(data);
                _stream.Write(data2, 0, data.Length);
            }
        }
    
}
}
