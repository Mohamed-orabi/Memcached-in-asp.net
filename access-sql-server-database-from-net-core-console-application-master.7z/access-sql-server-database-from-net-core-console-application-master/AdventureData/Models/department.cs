﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureData.Models
{
    public class department
    {
        public int DepartmentID { get; set; }

        public string Name { get; set; }

        public string GroupName { get; set; }

        public DateTime ModifiedDate { get; set; }
    }
}
